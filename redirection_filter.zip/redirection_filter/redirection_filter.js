document.addEventListener('DOMContentLoaded', function () {
    // Add click event listener to dropdown items
    document.querySelectorAll('.wordpress_menu_css #menu-1-303dcee .elementor-nav-menu--dropdown li a').forEach(function (item) {
        item.addEventListener('click', function (e) {
            e.preventDefault(); // Prevent default link behavior

            // Store the clicked item value in localStorage
            let dropdownItemName = e.target.textContent.trim();
            localStorage.setItem('dropdown_item_name', dropdownItemName);

            // Debugging: check if the localStorage is being set
            console.log('Dropdown item name stored:', dropdownItemName);

            // Redirect to the education page
            window.location.href = 'https://ifarmag.ca/education/';
        });
    });
});


document.addEventListener('DOMContentLoaded', function () {
    // Retrieve the stored dropdown item name from localStorage
    const storedItemName = localStorage.getItem('dropdown_item_name');

    if (storedItemName) {
        // Debugging: Check what value was retrieved
        console.log('Stored item name:', storedItemName);

        // Add a delay to ensure the elements are fully loaded
        setTimeout(() => {
            // Find all tab elements on the page
            const items = document.querySelectorAll('#uc_ue_buttons_post_filter_elementor_3062a31 .ue_taxonomy_item');

            let found = false;
            items.forEach(function (item) {
                // Get the text of the title within the tab
                const tabTitle = item.querySelector('.ue_taxonomy_item_content .ue_taxonomy_item_title')?.textContent.trim();

                // Debugging: Check each tab's title
                console.log('Tab Title:', tabTitle);

                // Check if the stored item matches the tab title
                if (storedItemName === tabTitle) {
                    console.log("Values Matched:", tabTitle);
                    found = true;

                    // Trigger a click on the .ue_taxonomy_item
                    item.click();

                    // Optionally, add a class to the matching item
                    item.classList.add('uc-selected');

                    // Clear the stored item after processing
                    localStorage.removeItem('dropdown_item_name');

                    // Exit the loop after finding the match
                    return;
                }
            });

            // If no match is found, log that the values didn't match
            if (!found) {
                console.log("Value Not Found");
            }
        }, 1000); // Delay to ensure elements are loaded
    } else {
        console.log("No item stored in localStorage.");
    }
});